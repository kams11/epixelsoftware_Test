document.getElementById("signupForm").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const formData = {
      firstName: document.getElementById("firstName").value,
      lastName: document.getElementById("lastName").value,
      email: document.getElementById("email").value,
      phoneNumber: document.getElementById("phoneNumber").value,
      password: document.getElementById("password").value,
    };
  
    const errors = validate(formData);
  
    if (Object.keys(errors).length === 0) {
      console.log("Form Submitted:", formData);
      alert("Form Submitted Successfully!");
    } else {
      displayErrors(errors);
    }
  });
  
  function validate(formData) {
    const errors = {};
  
    if (!formData.firstName.trim()) {
      errors.firstName = "First Name is required";
    }
  
    if (!formData.lastName.trim()) {
      errors.lastName = "Last Name is required";
    }
  
    const emailPattern = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (!formData.email || !emailPattern.test(formData.email)) {
      errors.email = "Please enter a valid email address";
    }
  
    const phonePattern = /^[0-9]{10}$/;
    if (!formData.phoneNumber || !phonePattern.test(formData.phoneNumber)) {
      errors.phoneNumber = "Please enter a valid phone number";
    }
  
    if (formData.password.length < 8) {
      errors.password = "Password must be at least 8 characters long";
    }
  
    return errors;
  }
  
  function displayErrors(errors) {
    document.getElementById("firstNameError").textContent = errors.firstName || "";
    document.getElementById("lastNameError").textContent = errors.lastName || "";
    document.getElementById("emailError").textContent = errors.email || "";
    document.getElementById("phoneNumberError").textContent = errors.phoneNumber || "";
    document.getElementById("passwordError").textContent = errors.password || "";
  }
  